#include<stdio.h>
struct abc
{
    int b;
    int d;
    char a;
    char c;
    char e;
    char f;
    char g;
    char o;


}v;
int main()
{
    printf("%d",sizeof(v));
}
