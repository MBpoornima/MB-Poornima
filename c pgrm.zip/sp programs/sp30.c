int main()
{

    int x;
    x=(1&&1)+(110/5)*(1||0)-(15*2);
    printf("%d",x);

}
