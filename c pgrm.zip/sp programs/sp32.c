int main()
{
    int a='z',b='g',z;
    z=(a>b)?printf("a is greater than b"):printf("b is greater than a");
}
