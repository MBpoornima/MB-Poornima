//bitwise//
int main()
{
    int a,b;
    printf("enter a and b");
    scanf("%d\n%d",&a,&b);
    printf("%d\n",a+a&b);
    printf("%d\n",b-a|b);
    printf("%d\n",a^b*a);
}
