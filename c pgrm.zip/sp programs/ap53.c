#include<stdio.h>
int main()
{

    char *name[9]={"anusha","shrushti","sumanth","vishal","omkar","akshata","sampada","kiran","kavya"};
    for(int i=0;i<9;i++)
    {
        printf("%s\t",name[i]);
    }
}
