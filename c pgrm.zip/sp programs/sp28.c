// shift   //
int main()
{
   int a=3,b=9,x;
   x=(a*b,a+b);
   printf("%d",x);

}
