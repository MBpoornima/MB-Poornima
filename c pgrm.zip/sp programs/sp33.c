// //
int main()
{
 char a;
 scanf("%c",&a);
 ((a>='a'&& a<='z')||(a>='A'&& a<='z'?printf("it is alphabet"):printf("its not alphabet");
}
