int main()
{
    int x;
    float a,b,c;
    printf("enter days x:\n");
    scanf("%d",&x);
    a=x/365;
    b=x/30;
    c=x/7.0;
    printf(" year are%f\n months are %f\n weeks are %f\n",a,b,c);
}
